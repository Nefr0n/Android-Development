![Снимок экрана 2024-02-24 020725](https://github.com/Evertume/Dodo_pizza/assets/117449684/11df1334-67d5-41dd-833b-3f0c4368a677)
![Снимок экрана 2024-02-24 020736](https://github.com/Evertume/Dodo_pizza/assets/117449684/e50b150a-7e9d-472a-ac1e-80d22d763f09)
![Снимок экрана 2024-02-24 020750](https://github.com/Evertume/Dodo_pizza/assets/117449684/537af5d6-52ff-4ff4-b459-51ca601e91b5)
