package com.example.dodopizza

import org.junit.Test
import org.junit.Assert.*
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(2, 1 + 1)
    }
}