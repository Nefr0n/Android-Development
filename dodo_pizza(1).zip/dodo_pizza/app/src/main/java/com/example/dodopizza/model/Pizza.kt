package com.example.dodopizza.model

data class Pizza(
    val title:String,
    val img:     Int,
    val desc :String,
    val price:   Int,
    val type: String,
    val size: String,
)
